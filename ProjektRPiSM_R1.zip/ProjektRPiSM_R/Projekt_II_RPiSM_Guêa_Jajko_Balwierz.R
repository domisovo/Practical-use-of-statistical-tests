#Pakiety, ktorych bedziemy uzywac
install.packages(c("coin", "ggpubr", "broom", "tidyverse", "ggplot2", "dplyr", "grid", "cowlot", "gridExtra", "tidyr", "countrycode"))
library(tidyr)
library(dplyr)
library(countrycode)
library(ggplot2)
library(coin)
library(ggpubr)
library(broom)
library(tidyverse)
library(gridExtra)
library(cowplot)
library(grid)

#Wczytanie i "posprzatnie" danych
pop <- read.csv("pop.csv")
PKB <- read.csv("gdp_pcap.csv")
agriculture<- read.csv("agriculture_percent_of_gdp.csv")
urban<- read.csv("urban_population_percent_of_total.csv")
CO2<-read.csv("co2_pcap_cons.csv")
renewable<-read.csv("eg_elc_rnwx_zs.csv")
industry<-read.csv("industry_percent_of_gdp.csv")

a <- gather(pop, year, pop, -country)
b<- gather(PKB, year, PKB, -country)
c<- gather(agriculture, year, agriculture, -country)
d<- gather(urban, year, urban, -country)
e<- gather(CO2, year, CO2, -country)
f<- gather(renewable, year, renewable, -country)
g<- gather(industry, year, industry, -country)

mergeCols <- c("year", "country")
tab1 <- inner_join(a, b, by=mergeCols)
tab2 <- inner_join(tab1, c, by=mergeCols)
tab3 <- inner_join(tab2, d, by=mergeCols)
tab4 <- inner_join(tab3, e, by=mergeCols)
tab5 <- inner_join(tab4, f, by=mergeCols) 
tabela <- inner_join(tab5, g, by=mergeCols)

tabela$year <- gsub('X','',tabela$year)
tabela <- tabela %>%
  filter(tabela$year %in% c(seq(1990, 2015)))

dane<- tabela %>%
  mutate(kontynent = countrycode(country, origin = "country.name",destination = "continent")) %>%
  rename(rok = year) %>%
  rename(kraj = country)

convert_to_numeric <- function(data) {
  data <- as.numeric(data)
  for (i in 1:length(data)) {
    value <- data[i]
    if (grepl("B", value)) {
      data[i] <- as.numeric(sub("B", "", value)) * 1e9
    } else if (grepl("M", value)) {
      data[i] <- as.numeric(sub("M", "", value)) * 1e6
    } else if (grepl("k", value)) {
      data[i] <- as.numeric(sub("k", "", value)) * 1e3
    } else {
      data[i] <- as.numeric(value)
    }
  }
  return(data)
}

convert_to_numeric_pop <- function(data) {
  data <- as.character(data)
  for (i in 1:length(data)) {
    value <- data[i]
    if (grepl("B", value)) {
      data[i] <- as.numeric(sub("B", "", value)) * 1e9
    } else if (grepl("M", value)) {
      data[i] <- as.numeric(sub("M", "", value)) * 1e6
    } else if (grepl("k", value)) {
      data[i] <- as.numeric(sub("k", "", value)) * 1e3
    }
  }
  return(data)
}

dane$CO2 <- gsub(",", ".", dane$CO2)  
dane$CO2 <- gsub("\\s+", "", dane$CO2)  
dane$CO2<-convert_to_numeric(dane$CO2)
dane$PKB<-convert_to_numeric_pop(dane$PKB)
dane$pop<-convert_to_numeric_pop(dane$pop)
dane$pop<-as.numeric(dane$pop)
dane$PKB<-as.numeric(dane$PKB)
dane <- dane[dane$kontynent != "Oceania", ]

dane<- na.omit(dane)
write.csv(dane, file = "dane_RPiSM.csv", row.names = FALSE)
dane

#Opisanie zmiennych
#Populacja
population_in_milions <- dane$pop/1000000

max_population <- max(dane$pop)
min_population <- min(dane$pop)

max_population_country <- dane %>%
  filter(pop == max_population, rok == "2014") %>%
  mutate(population_in_millions = ifelse(max_population != 0, sprintf("%.2f", pop/1e6), "0.00")) %>%
  select(kraj, population_in_millions)

min_population_country <- dane %>%
  filter(pop == min_population, rok == "2014") %>%
  mutate(population_in_millions = ifelse(min_population != 0, sprintf("%.2f", pop/1e6), "0.00")) %>%
  select(kraj, population_in_millions)

result_table <- bind_rows(max_population_country, min_population_country)
result_table

#PKB
summary(dane$PKB)

sd(dane$PKB)

pkb_dane <- dane %>%
  group_by(kontynent) %>%
  summarise(mean = mean(PKB), sd = sd(PKB))
pkb_dane

#Rolnictwo
summary(dane$agriculture)

max_rolnictwo <- max(dane$agriculture)
min_rolnictwo <- min(dane$agriculture)

max_rolnictwo_country <- filter(dane, agriculture == max_rolnictwo) %>%
  select(kraj, agriculture)

min_rolnictwo_country <- filter(dane, agriculture == min_rolnictwo) %>%
  select(kraj, agriculture)

wynik_rolnictwo <- bind_rows(max_rolnictwo_country, min_rolnictwo_country)
wynik_rolnictwo

#Urbanizacja
wykres_urban <- dane %>%
  group_by(kontynent, rok) %>%
  summarize(mean_urban = mean(urban, na.rm = TRUE))

ggplot(wykres_urban, aes(x = rok, y = mean_urban, color = kontynent, group = kontynent)) + 
  geom_line(size = 1.5) + 
  theme_bw() + 
  labs(title = "Średni współczynnik urbanizacji",
       subtitle = "w latach 1990 - 2014 na wybranych kontynentach",
       color = "Kontynent") +
  xlab("Rok") +
  ylab("Średni współczynnik urbanizacji") +
  theme(axis.text=element_text(size=10),
        axis.title=element_text(size=14),
        axis.text.y = element_text(size=10),
        axis.text.x = element_text(angle = 45, hjust = 1),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        plot.title = element_text(size = 14, face = "bold"))

#CO2
wykres_CO2 <- dane %>%
  group_by(kontynent, rok) %>%
  summarize(mean_CO2 = mean(CO2, na.rm = TRUE))

ggplot(wykres_CO2, aes(x = rok, y = mean_CO2, color = kontynent, group = kontynent)) + 
  geom_line(size = 1.5) + 
  theme_bw() + 
  labs(title = "Średnia wartość emisji CO2 na osobę",
       subtitle = "w latach 1990 - 2014 na wybranych kontynentach",
       color = "Kontynent") +
  xlab("Rok") +
  ylab("Średnia wartość emisji CO2") +
  theme(axis.text=element_text(size=10),
        axis.title=element_text(size=14),
        axis.text.y = element_text(size=10),
        axis.text.x = element_text(angle = 45, hjust = 1),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        plot.title = element_text(size = 14, face = "bold"))

#Odnawialna energia
wykres_renewable <- dane %>%
  group_by(kontynent, rok) %>%
  summarize(mean_ren = mean(renewable))
ggplot(wykres_renewable, aes(x = as.factor(kontynent), y = mean_ren, color = kontynent)) +
  geom_boxplot() + 
  scale_y_continuous(limits = c(15, 50), expand = c(0, 0)) +
  theme_bw() + 
  theme(legend.position="none") + 
  labs(title = "Średnia wartość użycia źródeł odnawialnej energii",
       subtitle = "na wybranych kontynentach w latach 1990 - 2014", 
       color = "Kontynent") +
  xlab("Kontynent") +
  ylab("Użycie źródeł odnawialnej enegii") +
  theme(axis.text=element_text(size=12),
        plot.title = element_text(size = 14, face = "bold"),
        axis.title=element_text(size=12))

#Przemysl
wykres_industry <- dane %>%
  group_by(kontynent, rok) %>%
  summarize(mean_industry = mean(industry, na.rm = TRUE))

ggplot(wykres_industry, aes(x = rok, y = mean_industry, color = kontynent, group = kontynent)) + 
  geom_line(size = 1.5) + 
  theme_bw() + 
  labs(title = "Średnia wartość przemysłu w PKB",
       color = "Kontynent") +
  xlab("Rok") +
  ylab("Średnia wartość przemysłu w PKB") +
  theme(axis.text=element_text(size=10),
        axis.title=element_text(size=14),
        axis.text.y = element_text(size=10),
        axis.text.x = element_text(angle = 45, hjust = 1),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        plot.title = element_text(size = 14, face = "bold"))

##############################################################################################

#Problem badawczy 1
#Zależność między udziałem przemysłu i rolnictwa w PKB a wykorzystaniem odnawialnej energii. 
#Który z tych czynników przyczynia się do większego wykorzystywania źródeł odnawialnej energii 
#przez wybrane państwa.

top_industry_countries <- dane %>%
  filter(rok == 2015) %>%
  top_n(30, industry) %>%
  arrange(desc(industry)) %>%
  select(kraj, renewable)

bottom_industry_countries <- dane %>%
  filter(rok == 2015) %>%
  arrange(industry) %>%
  slice_head(n = 30) %>%
  select(kraj, renewable)

top_agriculture_countries <- dane %>%
  filter(rok == 2015) %>%
  top_n(30, agriculture) %>%
  arrange(desc(agriculture)) %>%
  select(kraj, renewable)

bottom_agriculture_countries <- dane %>%
  filter(rok == 2015) %>%
  arrange(agriculture) %>%
  slice_head(n = 30) %>%
  select(kraj, renewable)

combined_summary_all <- bind_rows(
  bind_rows(
    dane %>%
      filter(rok == 2015, kraj %in% top_industry_countries$kraj) %>%
      summarize(
        srednia = mean(renewable, na.rm = TRUE),
        mediana= median(renewable, na.rm = TRUE),
        min = min(renewable, na.rm = TRUE),
        max = max(renewable, na.rm = TRUE),
        odchylenie_standardowe = sd(renewable, na.rm = TRUE)
      ) %>%
      mutate(Kategoria = "Najwyższy przemysł"),
    
    dane %>%
      filter(rok == 2015, kraj %in% bottom_industry_countries$kraj) %>%
      summarize(
        srednia = mean(renewable, na.rm = TRUE),
        mediana = median(renewable, na.rm = TRUE),
        min = min(renewable, na.rm = TRUE),
        max = max(renewable, na.rm = TRUE),
        odchylenie_standardowe = sd(renewable, na.rm = TRUE)
      ) %>%
      mutate(Kategoria = "Najniższy przemysł")
  ),
  
  bind_rows(
    dane %>%
      filter(rok == 2015, kraj %in% top_agriculture_countries$kraj) %>%
      summarize(
        srednia= mean(renewable, na.rm = TRUE),
        mediana = median(renewable, na.rm = TRUE),
        min = min(renewable, na.rm = TRUE),
        max = max(renewable, na.rm = TRUE),
        odchylenie_standardowe = sd(renewable, na.rm = TRUE)
      ) %>%
      mutate(Kategoria = "Najwyższe rolnictwo"),
    
    dane %>%
      filter(rok == 2015, kraj %in% bottom_agriculture_countries$kraj) %>%
      summarize(
        srednia= mean(renewable, na.rm = TRUE),
        mediana = median(renewable, na.rm = TRUE),
        min = min(renewable, na.rm = TRUE),
        max = max(renewable, na.rm = TRUE),
        odchylenie_standardowe = sd(renewable, na.rm = TRUE)
      ) %>%
      mutate(Kategoria = "Najniższe rolnictwo")
  )
)
porownanie_przemysl_rolnictwo <- combined_summary_all %>%
  select(Kategoria, everything())

porownanie_przemysl_rolnictwo

#Wykres 

dane_2015 <- dane %>%
  filter(rok == 2015)

industry_data <- dane_2015 %>%
  mutate(group = cut(industry, breaks = c(0, 10, 20, 30, 40, 50, 60, 70), labels = c("0-10%", "11-20%", "21-30%", "31-40%", "41-50%", "51-60%", "61-70%"), include.lowest = TRUE)) %>%
  na.omit()

agriculture_data <- dane_2015 %>%
  mutate(group = cut(agriculture, breaks = c(0, 10, 20, 30, 40, 50, 60, 70), labels = c("0-10%", "11-20%", "21-30%", "31-40%", "41-50%", "51-60%", "61-70%"), include.lowest = TRUE)) %>%
  na.omit()

# Wykres dla przemysłu
industry_ren <- ggplot(industry_data, aes(x = group, y = renewable)) +
  stat_summary(fun = mean, geom = "bar", fill = "indianred", position = "dodge", colour = "black") +
  labs(
    title = "Średnie użycie odnawialnej energii",
    subtitle = "w zależności od odsetka udziału przemysłu",
    x = "Grupa odsetka udziału przemysłu",
    y = "Średnie użycie energii odnawialnej"
  ) +
  theme_bw() +
  theme(plot.title = element_text(size = 12, face = "bold", hjust = 0.5),
        plot.subtitle = element_text(size = 10, hjust = 0.5)) +
  scale_x_discrete(drop = FALSE) +
  coord_cartesian(ylim = c(0, 15))

# Wykres dla rolnictwa
agriculture_ren <- ggplot(agriculture_data, aes(x = group, y = renewable)) +
  stat_summary(fun = mean, geom = "bar", fill = "darkseagreen", position = "dodge", colour = "black") +
  labs(
    title = "Średnie użycie odnawialnej energii",
    subtitle = "w zależności od odsetka udziału rolnictwa",
    x = "Grupa odsetka udziału rolnictwa",
    y = "Średnie użycie energii odnawialnej"
  ) +
  theme_bw() +
  theme(plot.title = element_text(size = 12, face = "bold", hjust = 0.5),
        plot.subtitle = element_text(size = 10, hjust = 0.5)) +
  scale_x_discrete(drop = FALSE) +
  coord_cartesian(ylim = c(0, 15))

plot_grid(industry_ren, agriculture_ren, nrow = 1)

# Testy statystyczne 
#Przemysl
dane_industry_low <- dane %>%
  filter(industry <= 20, rok >= 2000)

dane_industry_high <- dane %>%
  filter(industry > 20, rok >= 2000)

selected_values_industry_low <- dane_industry_low %>%
  sample_n(100, replace = FALSE) %>%
  select(renewable)
selected_values_industry_low

selected_values_industry_high <- dane_industry_high %>%
  sample_n(100, replace = FALSE) %>%
  select(renewable)
selected_values_industry_high

combined_selected_values_industry <- bind_cols(
  selected_values_industry_low %>% rename(industry_low = renewable),
  selected_values_industry_high %>% rename(industry_high = renewable)
)

print(combined_selected_values_industry)

wynik_testu_t_industry <- t.test(
  combined_selected_values_industry$industry_low,
  combined_selected_values_industry$industry_high
)

print(wynik_testu_t_industry)


#Rolnictwo
dane_agriculture_low <- dane %>%
  filter(agriculture <= 20, rok >= 2000)

dane_agriculture_high <- dane %>%
  filter(agriculture > 20, rok >= 2000)

selected_values_agriculture_low <- dane_agriculture_low %>%
  sample_n(100, replace = FALSE) %>%
  select(renewable)
selected_values_agriculture_low

selected_values_agriculture_high <- dane_agriculture_high %>%
  sample_n(100, replace = FALSE) %>%
  select(renewable)
selected_values_agriculture_high

combined_selected_values_agriculture <- bind_cols(
  selected_values_agriculture_low %>% rename(agriculture_low = renewable),
  selected_values_agriculture_high %>% rename(agriculture_high = renewable)
)

wynik_testu_t_agriculture <- t.test(
  combined_selected_values_agriculture$agriculture_low,
  combined_selected_values_agriculture$agriculture_high
)

wynik_testu_t_agriculture

print(wynik_testu_t_agriculture)

##############################################################################################

#Problem badawczy 2
#Korelacja między współczynnikiem urbanizacji a emisją gazów cieplarnianych. 
#Przeprowadzenie analizy, czy państwa, które posiadają wyższy współczynnik urbanizacji, 
#emitują więcej gazów cieplarnianych.

# Korelacja Pearsona
pearson_test <- cor.test(dane$urban, dane$CO2)
print(pearson_test)

# Obliczenie współczynnika Tau Kendalla za pomocą cor.test
kendall_test <- cor.test(dane$CO2, dane$urban, method = "kendall")

# Model regresji liniowej
model_liniowy <- lm(CO2 ~ urban, data = dane)

# Przekształcenie wyników do postaci tabeli
wyniki_tidy <- tidy(model_liniowy)

# Usunięcie wiersza dla interceptu
wyniki_tidy <- wyniki_tidy %>%
  filter(term != "(Intercept)")

# Wyświetlenie tabeli wyników
View(wyniki_tidy)

# Test Tau Kendalla
kendall_test_result <- cor.test(dane$urban, dane$CO2, method = "kendall")

# Wyświetlenie wyniku testu
print(kendall_test_result)

# Wykres punktowy i model regresji liniowej 
scatter_plot <- function(dane) {
  # Tworzenie wykresu punktowego z regresją liniową
  plot <- ggplot(dane, aes(x = urban, y = CO2)) +
    geom_point(color = "lightblue") +      
    geom_smooth(method = "lm", se = FALSE, color = "black") + 
    labs(title = "Scatter Plot",      
         x = "Współczynnik Urbanizacji",  
         y = "Emisja CO2") +           
    theme_minimal()                   
  
  return(plot)
}

# Wywołanie funkcji i przypisanie wyniku do zmiennej
wykres <- scatter_plot(dane)

# Wyświetlenie wykresu
print(wykres)

#Trend emisji gazów cieplarnianych
# Przekształć kolumnę "rok" na format daty
dane$rok <- as.Date(as.character(dane$rok), format = "%Y")

# Agregacja danych
dane_agregowane <- dane %>%
  group_by(rok) %>%
  summarise(Srednia_Emisja = mean(CO2))

# Wykres
ggplot(dane_agregowane, aes(x = rok, y = Srednia_Emisja)) +
  geom_line() +
  labs(title = "Trend emisji gazów cieplarnianych",
       x = "Czas",
       y = "Średnia emisja") +
  theme_minimal()

#Trend dla urbanizacji

# Agregacja danych
dane_agregowane1 <- dane %>%
  group_by(rok) %>%
  summarise(Urbanizacja = mean(urban))

# Wykres
ggplot(dane_agregowane1, aes(x = rok, y = Urbanizacja)) +
  geom_line() +
  labs(title = "Trend urbanizacji",
       x = "Czas",
       y = "Urbanizacji") +
  theme_minimal()

# Sortuj dane według kolumny CO2 w malejącej kolejności
posortowane_dane <- dane[order(-dane$CO2), ]

# Wyświetl pierwsze 5 wierszy dla największych wartości CO2
View((posortowane_dane[, c("CO2", "urban", "kraj", "rok")]))

# Sortuj dane według wartości CO2 (rosnąco)
posortowane_CO2 <- dane[order(dane$CO2), ]

# Wyświetl dane dla kolumn "CO2", "urban", "kraj", "rok"
View(posortowane_CO2[, c("CO2", "urban", "kraj", "rok")])

##############################################################################################

#Problem badawczy 3
#Sprawdzenie zależności między wielkością PKB per capita a emisją dwutlenku wegla. 
#Analiza sprawdzaja, czy kraje z większym PKB per capita emitują więcej gazów cieplarnianych. 

# Dodatkowe przygotowanie danych

# Rozkład emisji CO2
ggplot(dane, aes(x = CO2)) +
  geom_histogram(fill = "green", color = "black", bins = 30) +
  labs(title = "Rozkład emisji CO2",
       x = "Emisja CO2",
       y = "Liczba krajów") +
  theme_minimal()

# Rozkład PKB per capita
ggplot(dane, aes(x = PKB)) +
  geom_histogram(fill = "blue", color = "black", bins = 30) +
  labs(title = "Rozkład PKB per capita",
       x = "PKB per capita",
       y = "Liczba krajów") +
  theme_minimal()

# Test Wilcoxona dla PKB i CO2
wilcox_test_result_pkb_co2 <- wilcox.test(dane$PKB, dane$CO2)
cat("Test Wilcoxona dla PKB i CO2:\n")
print(wilcox_test_result_pkb_co2)
cat("\n\n")

# Analiza korelacji Pearsona dla całego zestawu danych
correlation_result_all <- cor.test(dane$PKB, dane$CO2, method = "pearson")
cat("Test korelacji Pearsona dla całego zestawu danych (PKB i CO2):\n")
print(correlation_result_all)
cat("\n\n")

# Analiza korelacji rangowego Spearmana dla całego zestawu danych
spearman_result_all <- cor.test(dane$PKB, dane$CO2, method = "spearman")
cat("Test rangowego Spearmana dla całego zestawu danych (PKB i CO2):\n")
print(spearman_result_all)
cat("\n\n")

# Dodaj kategorie PKB i CO2 do danych
dane$PKB_category <- ifelse(dane$PKB > mean(dane$PKB), "Wysokie PKB", "Niskie PKB")
dane$CO2_category <- ifelse(dane$CO2 > mean(dane$CO2), "Wysoka emisja", "Niska emisja")

regression_model <- lm(CO2 ~ PKB, data = dane)

# Wykres dla kategorii "Wysokie PKB"
ggplot(dane[dane$PKB_category == "Wysokie PKB", ], aes(x = PKB, y = CO2, color = CO2_category)) +
  geom_point(size = 3) +
  labs(title = "Zależność między PKB per capita a emisją CO2 (Wysokie PKB)",
       x = "PKB per capita",
       y = "Emisja CO2") +
  theme_minimal() +
  scale_color_manual(values = c("Wysoka emisja" = "#add8e6", "Niska emisja" = "#98fb98")) +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  annotate("text", x = min(dane$PKB[dane$PKB_category == "Wysokie PKB"]), 
           y = max(dane$CO2[dane$PKB_category == "Wysokie PKB"]), 
           label = paste("R^2 =", round(summary(regression_model)$r.squared, 2)), 
           hjust = 0, vjust = 1) +
  theme(legend.position = "top",
        legend.title = element_text(size = 10, face = "bold"),
        legend.text = element_text(size = 8),
        legend.key = element_blank())

# Wykres dla kategorii "Niskie PKB"
ggplot(dane[dane$PKB_category == "Niskie PKB", ], aes(x = PKB, y = CO2, color = CO2_category)) +
  geom_point(size = 3) +
  labs(title = "Zależność między PKB per capita a emisją CO2 (Niskie PKB)",
       x = "PKB per capita",
       y = "Emisja CO2") +
  theme_minimal() +
  scale_color_manual(values = c("Wysoka emisja" = "#dda0dd", "Niska emisja" = "#ff7f50")) +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  annotate("text", x = min(dane$PKB[dane$PKB_category == "Niskie PKB"]), 
           y = max(dane$CO2[dane$PKB_category == "Niskie PKB"]), 
           label = paste("R^2 =", round(summary(regression_model)$r.squared, 2)), 
           hjust = 0, vjust = 1) +
  theme(legend.position = "top",
        legend.title = element_text(size = 10, face = "bold"),
        legend.text = element_text(size = 8),
        legend.key = element_blank())
